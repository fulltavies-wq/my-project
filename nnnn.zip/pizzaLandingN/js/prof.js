document.addEventListener("DOMContentLoaded", () => {
    const userIcon = document.querySelector(".user-icon")
    const authBlock = document.getElementById("auth-block")
    const profileModal = document.getElementById("pm")
    const closeProfileButton = document.getElementById("close-botton")
    const loginButton = document.getElementById("login-btn")
    const registerButton = document.getElementById("register-btn")
    const errorMessage = document.getElementById("error-message")
    const registerErrorMessage = document.getElementById("register-error-message")
    const loginForm = document.getElementById("login-form")
    const registerForm = document.getElementById("register-form")
  
    // Инициализация пользователей
    const users = JSON.parse(localStorage.getItem("users")) || [
      {
        id: 1,
        firstName: "Иван",
        lastName: "Иванов",
        login: "ivan@example.com",
        password: "password123",
        marioCoins: 50,
      },
      {
        id: 2,
        firstName: "Петр",
        lastName: "Петров",
        login: "petr@example.com",
        password: "password456",
        marioCoins: 30,
      },
    ]
    localStorage.setItem("users", JSON.stringify(users))
  
    // Открытие / закрытие блока авторизации
    userIcon.addEventListener("click", () => {
      const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"))
  
      if (loggedInUser) {
        authBlock.classList.add("hidden")
        profileModal.classList.remove("hidden")
        displayProfile(loggedInUser)
      } else {
        authBlock.classList.toggle("hidden")
        resetAuthBlock()
      }
    })
  
    function resetAuthBlock() {
      document.getElementById("login").value = ""
      document.getElementById("password").value = ""
      document.getElementById("first-name").value = ""
      document.getElementById("last-name").value = ""
      document.getElementById("register-login").value = ""
      document.getElementById("register-password").value = ""
      document.getElementById("register-password-repeat").value = ""
      errorMessage.classList.add("hidden")
      registerErrorMessage.classList.add("hidden")
      loginForm.classList.remove("hidden")
      registerForm.classList.add("hidden")
    }
  
    // Обработка входа
    loginButton.addEventListener("click", () => {
      const loginInput = document.getElementById("login").value
      const passwordInput = document.getElementById("password").value
  
      const user = users.find((user) => user.login === loginInput && user.password === passwordInput)
  
      if (user) {
        authBlock.classList.add("hidden")
        profileModal.classList.remove("hidden")
        displayProfile(user)
        localStorage.setItem("loggedInUser", JSON.stringify(user))
        updateIconColor()
      } else {
        errorMessage.classList.remove("hidden")
      }
    })
  
    // Обработка регистрации
    registerButton.addEventListener("click", () => {
      const firstName = document.getElementById("first-name").value
      const lastName = document.getElementById("last-name").value
      const registerLogin = document.getElementById("register-login").value
      const registerPassword = document.getElementById("register-password").value
      const registerPasswordRepeat = document.getElementById("register-password-repeat").value
  
      // Проверка валидности полей
      if (!validateRegistration(firstName, lastName, registerLogin, registerPassword, registerPasswordRepeat)) {
        return
      }
  
      const existingUser = users.find((user) => user.login === registerLogin)
  
      if (existingUser) {
        registerErrorMessage.textContent = "Пользователь с таким email уже существует"
        registerErrorMessage.classList.remove("hidden")
      } else {
        const newUser = {
          id: users.length + 1,
          firstName,
          lastName,
          login: registerLogin,
          password: registerPassword,
          marioCoins: 100,
        }
        users.push(newUser)
        localStorage.setItem("users", JSON.stringify(users))
        localStorage.setItem("loggedInUser", JSON.stringify(newUser))
        authBlock.classList.add("hidden")
        profileModal.classList.remove("hidden")
        displayProfile(newUser)
        updateIconColor()
        showSuccessMessage("Регистрация прошла успешно")
      }
    })
  
    function validateRegistration(firstName, lastName, email, password, passwordRepeat) {
      let isValid = true
      registerErrorMessage.textContent = ""
  
      if (firstName.length < 2 || lastName.length < 2) {
        registerErrorMessage.textContent += "Имя и фамилия должны быть не менее 6 символов. "
        isValid = false
      }
  
      if (!email.includes("@")) {
        registerErrorMessage.textContent += "Email должен содержать символ @. "
        isValid = false
      }
  
      if (password !== passwordRepeat) {
        registerErrorMessage.textContent += "Пароли не совпадают. "
        isValid = false
      }

      const passwordSim = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#!%&?])[A-Za-z0-9@#!%&?]{1,}$/;
      if (!passwordSim.test(password)) {
          registerErrorMessage.textContent += "Пароль должен содержать как минимум 1 заглавную букву, 1 цифру и 1 специальный символ (@#!%&?).";
          isValid = false;
      }
  
      if (!isValid) {
        registerErrorMessage.classList.remove("hidden")
      }
  
      return isValid
    }
  
    function showSuccessMessage(message) {
      const successMessage = document.createElement("div")
      successMessage.textContent = message
      successMessage.classList.add("success-message")
      authBlock.appendChild(successMessage)
      setTimeout(() => {
        successMessage.remove()
      }, 3000)
    }
  
    // Обработка закрытия профиля
    closeProfileButton.addEventListener("click", () => {
      profileModal.classList.add("hidden")
    })
  
    // Обработка выхода
    document.getElementById("vihodbotton").addEventListener("click", () => {
      localStorage.removeItem("loggedInUser")
      profileModal.classList.add("hidden")
      authBlock.classList.remove("hidden")
      updateIconColor()
    })
  
    // Функция для отображения профиля
    function displayProfile(user) {
      document.getElementById("profinf").innerHTML = `
              <p>Имя: ${user.firstName}</p>
              <p>Фамилия: ${user.lastName}</p>
              <p>Email: ${user.login}</p>
              <p>Марио-коины: ${user.marioCoins}</p>
          `
    }
  
    // Показать/скрыть формы
    document.getElementById("show-register").addEventListener("click", () => {
      loginForm.classList.add("hidden")
      registerForm.classList.remove("hidden")
      errorMessage.classList.add("hidden")
      registerErrorMessage.classList.add("hidden")
    })
  
    document.getElementById("show-login").addEventListener("click", () => {
      registerForm.classList.add("hidden")
      loginForm.classList.remove("hidden")
      errorMessage.classList.add("hidden")
      registerErrorMessage.classList.add("hidden")
    })
  
    // Проверка при загрузке страницы
    const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"))
    if (loggedInUser) {
      profileModal.classList.remove("hidden")
      displayProfile(loggedInUser)
    }
  
    function updateIconColor() {
      const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"))
      userIcon.style.fill = loggedInUser ? "#FF00FF" : "#000000"
    }
  
    // Вызов функции при загрузке страницы
    updateIconColor()
  })
  