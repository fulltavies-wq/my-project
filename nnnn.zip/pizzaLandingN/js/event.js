function AnimateEvent() {
     const pizzas = document.querySelector('.pizza');
     const salad = document.querySelector('.salad');
     const screenWidth = window.innerWidth;
     const screenHeight = window.innerHeight;
     
     // Анимация пиццы уезжающей вправо
     pizzas.style.transform = `translateX(${screenWidth}px)` ;
    
     // Анимация салата уезжающего влево
     salad.style.transform = `translateX(-${screenWidth}px)` ;
    
     // Плавное появление событий
     const content = document.getElementById('content');
     content.classList.remove('hidden');
     setTimeout(() => {
      content.classList.add('visible');
      const eventImages = document.querySelectorAll('.event-img img');
      eventImages.forEach((img, index) => {
       setTimeout(() => {
        img.classList.add('animate');
       }, index * 300); // Время задержки для появления
      });
     }, 2000); // Появление после 2 секунд задержки
    }
    