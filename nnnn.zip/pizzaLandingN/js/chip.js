function toggleDetails(element) {
  const details = element.querySelector(".det")
  const arrowContainer = element.querySelector(".chip-item__arrow-container")

  document.querySelectorAll(".chip-item").forEach((item) => {
    if (item !== element) {
      item.classList.remove("active")
      item.querySelector(".det").classList.remove("pr")
    }
  })

  element.classList.toggle("active")
  details.classList.toggle("pr")
}

document.addEventListener("DOMContentLoaded", async () => {
  try {
      
      await loadData();

      const chipItems = document.querySelectorAll(".chip-item");

      chipItems.forEach(item => {
          item.addEventListener("click", () => {
              const details = item.querySelector(".chip-item__details");

              if (details) {
                  
                  const isVisible = details.classList.contains("visible");

                  // закрыть все открытые блоки
                  chipItems.forEach(i => {
                      const otherDetails = i.querySelector(".chip-item__details");
                      if (otherDetails) {
                          otherDetails.classList.remove("visible");
                      }
                  });

                  // если  блок был закрыт, то открыть его
                  if (!isVisible) {
                      details.classList.add("visible");
                  }
              }
          });
      });
  } catch (error) {
      console.error("Ошибка при загрузке данных или инициализации:", error);
  }
});

async function loadData() {
  // задержка загрузки данных
  return new Promise(resolve => {
      setTimeout(() => {
          console.log("Данные успешно загружены!");
          resolve();
      }, 500); 
  });
}