const itemsList = [
    {
        imgSrc: "img/reviews/client1happy.jpg",
        imgAlt: "Фото клиента",
        clientInfo: "Дядя Игорь, г. Москва",
        clientGrade: 5,
        clientComment: "Я вне себя от радости! Пицца нереально вкусная! Особенно колбасная!",
        altData: {
            imgSrc: "img/reviews/client1sad.jpg",
            clientGrade: 1,
            clientComment: "Меня тошнит от ваших колбасных пицц!"
        }
    },
    {
        imgSrc: "img/reviews/client2.jpg",
        imgAlt: "Фото клиента",
        clientInfo: "Антонио Багратто, г.Флоренция",
        clientGrade: 5,
        clientComment: "Я обожаю это место!",
        altData: {
            clientGrade: 1,
            clientComment: "Я ненавижу это место!"
        }
    },
    {
        imgSrc: "img/reviews/client3.jpg",
        imgAlt: "Фото клиента",
        clientInfo: "Иван Иван, г. Тверь",
        clientGrade: 5,
        clientComment: "Я люблю это пицца и покупать вся еда дешево!",
        altData: {
            clientGrade: 2,
            clientComment: "Жить Россия устать."
        }
    }
];

let elementIndex = 0;

const sliderLine = document.querySelector(".js-reviews__sliderLine");
let reviewItems = {};

const buttonPrev = document.querySelector(".js-slider-btn-prev");
const buttonNext = document.querySelector(".js-slider-btn-next");

function displayReviews() {
    sliderLine.innerHTML = '';
    itemsList.forEach(item => {
        let reviewItemsTemp = `
            <div class="js-review-item review-item">
                <div class="review-item__head">
                    <div class="review-item__img-container">
                        <img class="review-item__img" src="${item.imgSrc}" alt="${item.imgAlt}">
                    </div>
                    <span class="review-item__visitor-info">${item.clientInfo}</span>
                    <div class="review-item__grade-block">
                        <span class="review-item__grade-icon material-symbols-outlined">kid_star</span>
                        <span class="review-item__grade-value">${item.clientGrade}</span>
                    </div>
                </div>
                <p class="review-item__review-text">${item.clientComment}</p>
            </div>`;
        sliderLine.innerHTML += reviewItemsTemp;
    });
    reviewItems = document.querySelectorAll(".js-review-item");
}

function slide(index) {
    sliderLine.setAttribute("style", `transform: translateX(${-1 * index * 100 / reviewItems.length}%)`);
}

displayReviews();

buttonNext.addEventListener('click', () => {
    elementIndex = (elementIndex + 1) % reviewItems.length;
    slide(elementIndex);
});

buttonPrev.addEventListener('click', () => {
    elementIndex = (elementIndex - 1 + reviewItems.length) % reviewItems.length;
    slide(elementIndex);
});

const reviewFormModal = document.getElementById('review-form-modal');
const reviewForm = document.getElementById('review-form');
const createReviewBtn = document.getElementById('create-review-btn');
const closeModalBtn = document.getElementById('close-modal');

function openReviewForm() {
    reviewFormModal.style.display = 'block';
}

function closeReviewForm() {
    reviewFormModal.style.display = 'none';
    reviewForm.reset();
    clearErrors();
}

function clearErrors() {
    document.getElementById('name-error').textContent = '';
    document.getElementById('rating-error').textContent = '';
    document.getElementById('comment-error').textContent = '';
}

function validateForm() {
    let isValid = true;
    const nameInput = document.getElementById('name');
    const ratingInput = document.getElementById('rating');
    const commentInput = document.getElementById('comment');

    clearErrors();

    if (!nameInput.value.trim()) {
        document.getElementById('name-error').textContent = 'Заполните поле "Кто вы?"';
        isValid = false;
    }
    if (!ratingInput.value) {
        document.getElementById('rating-error').textContent = 'Заполните поле "Ваша оценка"';
        isValid = false;
    }
    if (!commentInput.value.trim() || commentInput.value.length < 5) {
        document.getElementById('comment-error').textContent = 'Комментарий короткий.';
        isValid = false;
    }
    return isValid;
}

reviewForm.addEventListener('submit', function(event) {
    event.preventDefault();
    if (validateForm()) {
        const name = document.getElementById('name').value.trim();
        const rating = parseInt(document.getElementById('rating').value);
        const comment = document.getElementById('comment').value.trim();

        itemsList.push({
            imgSrc: "img/reviews/avatar.jpg",
            imgAlt: "Фото клиента",
            clientInfo: name,
            clientGrade: rating,
            clientComment: comment,
            altData: {}
        });

        displayReviews();
        closeReviewForm();
    }
});

createReviewBtn.addEventListener('click', openReviewForm);
closeModalBtn.addEventListener('click', closeReviewForm);
