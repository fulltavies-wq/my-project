const cartToggleButton = document.getElementById('toggle-cart');
const cart = document.getElementById('cart');
const selectedItemsContainer = document.getElementById('selected-items');
const totalPriceContainer = document.getElementById('total-price');
const orderForm = document.getElementById('order-form');
const orderButton = document.getElementById('order-button');
const closeCartButton = document.getElementById('close-cart');
const marioCoinsElement = document.getElementById('mario-coins');
const deductCoinsCheckbox = document.getElementById('deduct-coins');
const coinsToDeductInput = document.getElementById('coins-to-deduct');
const resultMessage = document.getElementById('result-message');

let cartItems = [];
let marioCoins = parseInt(marioCoinsElement.textContent, 10); // Присваиваем марио-коины
let totalPrice = 0;

cartToggleButton.addEventListener('click', () => {
    cart.style.display = cart.style.display === 'none' ? 'block' : 'none';
    renderCart();
});

closeCartButton.addEventListener('click', () => {
    cart.style.display = 'none';
});

// Пример добавления товаров в корзину (можно убрать или заменить на реальные товары)
function addToCart(name, price) {
    const existingItem = cartItems.find(item => item.name === name);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cartItems.push({ name, price, quantity: 1 });
    }
    renderCart();
}

        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', () => {
                const menuItem = button.parentElement;
                const itemName = menuItem.getAttribute('data-name');
                const itemPrice = parseFloat(menuItem.getAttribute('data-price'));

                const existingItem = cartItems.find(item => item.name === itemName);
                if (existingItem) {
                    existingItem.quantity++;
                } else {
                    cartItems.push({ name: itemName, price: itemPrice, quantity: 1 });
                }

                renderCart();
            });
        });
function renderCart() {
    selectedItemsContainer.innerHTML = '';
    let totalItemsCount = 0;
    totalPrice = 0;

    if (cartItems.length === 0) {
        selectedItemsContainer.innerHTML = '<p>Корзина пуста</p>';
        orderButton.disabled = true;
        return;
    } else {
        cartItems.forEach(item => {
            totalItemsCount += item.quantity; // Считаем общее количество товаров
            selectedItemsContainer.innerHTML += `
                <div>
                    ${item.name} - ${item.quantity} шт. - ${item.price * item.quantity}р
                    <button onclick="changeQuantity('${item.name}', 1)">+</button>
                    <button onclick="changeQuantity('${item.name}', -1)">-</button>
                </div>
            `;
            totalPrice += item.price * item.quantity; // Накопление итоговой цены
        });
        updateTotalPrice();
        orderButton.disabled = false;
    }
}

// Функция обновления итоговой цены, включая списание марио-коинов
function updateTotalPrice() {
    const deliveryFee = totalPrice < 1000 ? 500 : 0;
    let displayedTotalPrice = totalPrice + deliveryFee;

    if (deductCoinsCheckbox.checked) {
        // Получаем количество марио-коинов, которые пользователь хочет списать
        const coinsToDeduct = Math.min(marioCoins, parseInt(coinsToDeductInput.value) || 0);
        if (coinsToDeduct > 0 && coinsToDeduct <= marioCoins) {
            displayedTotalPrice -= coinsToDeduct;
        }
    }

    totalPriceContainer.innerHTML = `Итого: ${displayedTotalPrice}р`;
}

// Обновляем итоговую цену при изменении чекбокса или значения для списания
deductCoinsCheckbox.addEventListener('change', updateTotalPrice);
coinsToDeductInput.addEventListener('input', updateTotalPrice);

orderForm.addEventListener('submit', (event) => {
    event.preventDefault();
    // Списываем марио-коины, если чекбокс установлен
    if (deductCoinsCheckbox.checked) {
        const coinsToDeduct = Math.min(marioCoins, parseInt(coinsToDeductInput.value) || 0);
        marioCoins -= coinsToDeduct; // Списываем марио-коины
        marioCoinsElement.textContent = marioCoins; // Обновляем отображаемые марио-коины
    }

    // Составление данных заказа
    const orderData = {
        items: cartItems,
        total: totalPriceContainer.innerText,
        name: orderForm.name.value,
        address: orderForm.address.value,
        phone: orderForm.phone.value
    };

    console.log(orderData);
    alert('Спасибо за покупку, ожидайте нашего звонка!');

    // Очистка формы и корзины
    orderForm.reset();
    cartItems = [];
    renderCart();
    cart.style.display = 'none';
    totalPrice = 0; // Сбрасываем общую цену
    resultMessage.textContent = ''; // Сбрасываем текст сообщения
    coinsToDeductInput.value = 0; // Сбрасываем одно количество марио-коинов
    updateTotalPrice(); // Пересчитываем цену после оформления заказа
});

function changeQuantity(itemName, change) {
    const item = cartItems.find(item => item.name === itemName);
    item.quantity += change;
    if (item.quantity <= 0) {
        cartItems = cartItems.filter(item => item.name !== itemName);
    }

    renderCart(); // Прорисовка корзины после изменения
}

